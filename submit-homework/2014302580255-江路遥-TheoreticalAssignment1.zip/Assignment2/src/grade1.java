import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.util.LinkedList;
import java.util.List;

public class grade1 {
	public static void main(String[] args) throws ParseException, IOException {		
		InputStreamReader reader = new InputStreamReader(new FileInputStream("F://�½��ļ��� (3)//Assignment2//grade.txt"),"utf-16");

		String a ="";
		int b;
		while((b=reader.read())!=-1){  			               
            char c = (char) b;  
             a+=String.valueOf(c);  
    }
System.out.println(a);
String[] strs = a.replaceAll("\r", "").split("\n");
System.out.println(strs);
List<String> list = new LinkedList<String>();
List<String> sortList = new LinkedList<String>();
for(int i=1;i<strs.length;i++){
list.add(strs[i]);
}
for(int k=0;k<list.size();k++){
String s1 = list.get(k).replaceAll("\r", "");
String[] personInfo1 = s1.split("\t");

for(int j=list.size()-1;j>=0;j--){
double xf1 = Integer.valueOf(personInfo1[2]);
int cj1 = Integer.valueOf(personInfo1[3]);
double jq=xf1*cj1;
double n=xf1;
String s2 = list.get(j);
String[] personInfo2 = s2.split("\t");
int xf2 = Integer.valueOf(personInfo2[2]);
int cj2 = Integer.valueOf(personInfo2[3]);
n=xf1+xf2;
jq=jq+xf2*cj2;
double jqg=jq/n;
if(cj1<cj2){
	break;
}else{
	if(j==0){
		sortList.add(s1);
		
		list.remove(s1);
		k=-1;
	}
}
}
}
System.out.println(list.size());
System.out.println(sortList.size());
List<String> jqg = null;
System.out.println(jqg.size());

a = strs[0];
for(String str:sortList){
a += "\n" + str;
}

File f = new File("F://�½��ļ��� (3)//Assignment2/grade1.txt");
OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(f));
writer.write(a, 0, a.length());
writer.close();
}

}
